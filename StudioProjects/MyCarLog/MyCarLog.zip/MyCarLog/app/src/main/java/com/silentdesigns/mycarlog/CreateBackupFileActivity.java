/**
 * Copyright 2013 Google Inc. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.silentdesigns.mycarlog;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import android.content.Intent;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.OpenFileActivityBuilder;
import com.google.android.gms.drive.DriveApi.ContentsResult;
import com.google.android.gms.drive.DriveFolder.DriveFileResult;
import com.google.android.gms.drive.MetadataChangeSet;

/**
 * An activity to illustrate how to create a file.
 */
public class CreateBackupFileActivity extends BaseDemoActivity {

    protected static final String TAG = "CreateBackupFileActivity";

	private static final int REQUEST_CODE_OPENER = 1;

	protected static final int REQUEST_CODE_CREATOR = 0;

	protected String mLog;

	

	@Override
    public void onConnected(Bundle connectionHint) {
        super.onConnected(connectionHint);
        mLog = CarLogHome.prefs.getString("Log", "");
        
        // create new contents resource
        
        Drive.DriveApi.newContents(getGoogleApiClient())
                .setResultCallback(contentsCallback);
    }
        
    final private ResultCallback<ContentsResult> contentsCallback = new
                ResultCallback<ContentsResult>() {
            @Override
            public void onResult(ContentsResult result) {
                if (!result.getStatus().isSuccess()) {
                    // Handle error
                	showMessage("Error creating file");
                    return;
                }

                
                
				
                OutputStream outputStream = result.getContents().getOutputStream();
                //DriveId id = result.getContents().getDriveId();
                //CarLogHome.setmBackupDriveId(id.encodeToString());
                try {
					outputStream.write(mLog.getBytes());
				} catch (IOException e1) {
					Log.i(TAG, "Error writing string to outputstream: " + e1.toString());
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                
                MetadataChangeSet metadataChangeSet = new MetadataChangeSet.Builder()
                        .setMimeType("text/plain").setTitle("MyCarLog Backup.txt").build();
                IntentSender intentSender = Drive.DriveApi
                        .newCreateFileActivityBuilder()
                        .setInitialMetadata(metadataChangeSet)
                        .setInitialContents(result.getContents())
                        .build(getGoogleApiClient());
                try {
                    startIntentSenderForResult(intentSender, REQUEST_CODE_CREATOR, null, 0, 0, 0);
                } catch (SendIntentException e) {
                    // Handle the exception
                }
            }
        };
	

    
    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        switch (requestCode) {
            
            case REQUEST_CODE_CREATOR:
                // Called after a file is saved to Drive.
                if (resultCode == RESULT_OK) {
                    Log.i(TAG, "Backup file successfully saved.");
                    DriveId driveId = (DriveId) data.getParcelableExtra(
                            OpenFileActivityBuilder.EXTRA_RESPONSE_DRIVE_ID);
                    CarLogHome.setmBackupDriveId(driveId.encodeToString());
                    showMessage("Created a backup file");
                    finish();
                }
                break;
        }
    }
}
