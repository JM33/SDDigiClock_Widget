/**
 * Copyright 2013 Google Inc. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.silentdesigns.mycarlog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ProgressBar;

import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi.ContentsResult;
import com.google.android.gms.drive.DriveApi.DriveIdResult;
import com.google.android.gms.drive.DriveFile.DownloadProgressListener;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveId;

/**
 * Activity to illustrate how to retrieve and read file contents.
 */
public class RetrieveBackupContentsActivity extends BaseDemoActivity {

    private static final String TAG = "RetrieveContentsActivity";
	private String mLog;
	private ProgressBar mProgressBar;
	
	@Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_progress);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mProgressBar.setMax(100);
    }
	
    @Override
    public void onConnected(Bundle connectionHint) {
        super.onConnected(connectionHint);
        
        //mLog = connectionHint.getString("Log");
       Log.i(TAG, "Restoring Backup "+ CarLogHome.getmBackupDriveId());
        Drive.DriveApi.fetchDriveId(getGoogleApiClient(), CarLogHome.getmBackupDriveId())
                .setResultCallback(idCallback);
    }

    final private ResultCallback<DriveIdResult> idCallback = new ResultCallback<DriveIdResult>() {
        @Override
        public void onResult(DriveIdResult result) {
            new RetrieveDriveFileContentsAsyncTask(
                    RetrieveBackupContentsActivity.this).execute(result.getDriveId());
        }
    };
    
    final private class RetrieveDriveFileContentsAsyncTask
            extends ApiClientAsyncTask<DriveId, Boolean, String> {

        public RetrieveDriveFileContentsAsyncTask(Context context) {
            super(context);
        }

        @Override
        protected String doInBackgroundConnected(DriveId... params) {
            String contents = null;
            //showMessage(params.toString());
            
         // Reset progress dialog back to zero as we're
            // initiating an opening request.
            mProgressBar.setProgress(0);
            DownloadProgressListener listener = new DownloadProgressListener() {
                @Override
                public void onProgress(long bytesDownloaded, long bytesExpected) {
                    // Update progress dialog with the latest progress.
                    int progress = (int)(bytesDownloaded*100/bytesExpected);
                    Log.d(TAG, String.format("Loading progress: %d percent", progress));
                    mProgressBar.setProgress(progress);
                }
            };
            DriveFile file = Drive.DriveApi.getFile(getGoogleApiClient(),  DriveId.decodeFromString(CarLogHome.getmBackupDriveId()));
            
            
            ContentsResult contentsResult =
                    file.openContents(getGoogleApiClient(), DriveFile.MODE_READ_ONLY, listener).await();
            if (!contentsResult.getStatus().isSuccess()) {
                return null;
            }
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(contentsResult.getContents().getInputStream()));
            StringBuilder builder = new StringBuilder();
            String line;
            try {
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
                contents = builder.toString();
                
                CarLogHome.SaveStringPreferences("Log", contents);
                //CarLogHome.readLog();
                //showMessage(contents);
                //Log.i(TAG, contents);
                CarLogHome.refresh();
            } catch (IOException e) {
                Log.e(TAG, "IOException while reading from the stream", e);
            }

            file.discardContents(getGoogleApiClient(), contentsResult.getContents()).await();
            return contents;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result == null) {
                showMessage("Error while reading from the file");
                return;
            }
            showMessage("File restored successfully");
            finish();
        }
    }
}
